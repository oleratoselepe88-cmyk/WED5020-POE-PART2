# Sweet Crumb Home Bakery — Website (WEDE5020, Part 2)

## Project Overview
A 5-page static website for Sweet Crumb Home Bakery, a hypothetical home-based
bakery specialising in handmade chocolate croissants. Built as Part 2 of the
WEDE5020 Portfolio of Evidence: CSS styling and responsive design, built on
top of the Part 1 HTML foundation.

## Student Information
- Full Name: Olerato Owethu Selepe
- Student Number: ST10511014
- Group: 1

## Website Goals and Objectives
- Move from informal social-media ordering to a professional online presence.
- Let customers browse the menu and submit structured pre-orders/enquiries.
- Build trust through clear information about the baker, ingredients, and collection points.

## Key Features and Functionality
- Responsive 5-page site: Home, About, Menu, Enquiry (order form), Contact.
- Client-side validated enquiry form (name, contact, item, quantity, date).
- Client-side validated contact form (name, email, message).
- Two embedded collection-point maps on the Contact page.
- Mobile-friendly navigation (checkbox-based hamburger menu, no JS required to open/close).
- External stylesheet with a CSS reset, a consistent typography scale, and
  CSS custom properties (variables) for colour and spacing so the whole site
  can be re-themed from one place.
- CSS Grid used for the card/menu layouts and the contact collection points;
  Flexbox used for the header/navigation bar.
- Interactive states (`:hover`, `:focus`/`:focus-visible`, `:active`) on links,
  buttons, and form fields for accessibility and visual feedback.
- Fully responsive layout with three tiers — desktop, tablet (≤1024px), and
  mobile (≤640px) — using relative units (`rem`, `em`, `%`) rather than fixed
  pixel values.
- Responsive images: menu photos and the baker portrait use `srcset`/`sizes`
  (and a `<picture>` element for the baker portrait) so smaller devices
  download smaller image files.

## Timeline and Milestones
See the Website Project Proposal document for the full timeline (Weeks 1-7).

## Part 2 Details
This submission covers Part 2: Designing the Visuals — CSS styling and
responsive design. It builds on the Part 1 HTML structure and includes:
1. Corrections/edits made in response to Part 1 feedback (see Changelog).
2. An external CSS stylesheet (`css/style.css`) with a CSS reset and a base
   style (font family, font size, colour scheme, margin/padding).
3. Typography styling using a `rem`-based type scale (`--step--1` to `--step-4`
   custom properties).
4. A layout structure built with CSS Grid (`.grid`, `.locations`) and Flexbox
   (`.nav-wrap`, `nav ul`).
5. Visual styling with `color`, `background-color`, `border`, and `box-shadow`,
   plus `:hover`, `:focus`, and `:active` pseudo-classes for interactivity.
6. Responsive styling for tablet and mobile using media queries, relative
   units (`rem`/`em`/`%`), and responsive images (`srcset`, `sizes`, `picture`).
Part 3 (SEO, forms enhancement, external service integration) will follow in
a future submission.

## Screenshot Evidence (Desktop / Tablet / Mobile)
> **To do before submission:** add screenshots of the site at desktop
> (≥1024px), tablet (~768px), and mobile (~375px) widths — for at least the
> Home and Menu pages — using your browser's DevTools device toolbar, and
> place them here (e.g. in a `screenshots/` folder) with a short caption for
> each, as required by the brief.

- Desktop (1024px+): _add screenshot(s) here_
- Tablet (~768px): _add screenshot(s) here_
- Mobile (~375px): _add screenshot(s) here_

## Sitemap
```
index.html      -> Home
about.html      -> About Us
products.html   -> Menu / Products
enquiry.html    -> Order / Enquiry form
contact.html    -> Contact + collection points + map
```

## File and Folder Structure
```
/
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── images/
│   ├── hero-croissant.jpg
│   ├── baker-placeholder.jpg / -400.jpg / -800.jpg / -1200.jpg
│   ├── choco croissants.jpg  (+ choco-croissants-400/800/1200.jpg)
│   ├── almond croissant.jpg  (+ almond-croissant-400/800/1200.jpg)
│   ├── seasonal-special.jpg  (+ seasonal-special-400/800/1200.jpg)
│   └── croissant box.jpg     (+ croissant-box-400/800/1200.jpg)
└── README.md
```

## Changelog

### Part 1 feedback corrections
- v1.1 — Reviewed Part 1 feedback and confirmed HTML structure, semantic
  landmarks, and navigation labelling across all five pages ahead of Part 2
  styling work.

### Part 2 — CSS styling and responsive design
- v2.0 — Added a formal CSS reset (`box-sizing`, margin/padding reset, list
  style reset) and a `rem`-based typography scale via CSS custom properties.
- v2.1 — Converted fixed pixel spacing (padding/margin on buttons, cards,
  forms, and the footer) to relative `em`/`rem` units so spacing scales with
  font size; retained `%`-based widths on form fields and embedded maps.
- v2.2 — Added `:focus-visible` outline styles across links, buttons, and
  form fields, plus `:active` states on the primary button and nav links, to
  improve keyboard accessibility and interactive feedback.
- v2.3 — Added `box-shadow` and a subtle lift transform on menu/card hover,
  and refined the CTA button's `hover`/`active` shadow states.
- v2.4 — Restructured the responsive breakpoints into a clear three-tier
  system: desktop (default), tablet (`max-width: 1024px`), and mobile
  (`max-width: 640px`), with breakpoint-specific hero, grid, and navigation
  adjustments.
- v2.5 — Generated and wired up responsive image variants (400w/800w/1200w)
  for the four menu photos and the baker portrait, using `srcset`/`sizes` on
  the menu images and a `<picture>` element with `<source media>` for the
  baker portrait on the About page.

### Part 1 (prior submission)
- v0.1 — Initial HTML structure and navigation for all 5 pages.
- v0.2 — CSS styling applied (colour scheme, typography, responsive layout).
- v0.3 — JavaScript form validation added for enquiry and contact forms.
- v0.4 — Placeholder images added; replace with final licensed/original photography before final submission.

## References
- W3Schools, 2026. HTML Forms. Available at: https://www.w3schools.com/html/html_forms.asp
- MDN Web Docs, 2026. Client-side form validation. Available at: https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation
- Google, 2026. Google Maps Embed (no API key). Available at: https://www.google.com/maps
- MDN Web Docs, 2026. Using CSS custom properties (variables). Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties
- MDN Web Docs, 2026. Responsive images. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- MDN Web Docs, 2026. CSS Grid Layout. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs, 2026. Flexbox. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- MDN Web Docs, 2026. Using media queries. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
- CSS-Tricks, 2026. A Complete Guide to CSS Media Queries. Available at: https://css-tricks.com/a-complete-guide-to-css-media-queries/
