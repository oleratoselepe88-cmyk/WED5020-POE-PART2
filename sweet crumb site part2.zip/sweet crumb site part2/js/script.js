/* =========================================================
   Sweet Crumb Home Bakery — script.js
   Handles client-side validation for the enquiry and contact
   forms, plus small UX touches (mobile nav auto-close).
   ========================================================= */

// ---------- Helper: show/clear a field error ----------
function setError(fieldId, message) {
  const el = document.getElementById('err-' + fieldId);
  if (el) el.textContent = message;
}

function clearErrors(errorIds) {
  errorIds.forEach(id => setError(id, ''));
}

// ---------- Enquiry / order form ----------
const enquiryForm = document.getElementById('enquiry-form');

if (enquiryForm) {
  enquiryForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const fullName = document.getElementById('full-name');
    const contact = document.getElementById('contact');
    const item = document.getElementById('item');
    const quantity = document.getElementById('quantity');
    const collectionDate = document.getElementById('collection-date');

    const errorIds = ['full-name', 'contact', 'item', 'quantity', 'collection-date'];
    clearErrors(errorIds);

    let isValid = true;

    if (fullName.value.trim().length < 2) {
      setError('full-name', 'Please enter your full name.');
      isValid = false;
    }

    // Accept either a phone number (digits, spaces, +, -) or an email address
    const phonePattern = /^[0-9+\s-]{7,}$/;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!phonePattern.test(contact.value.trim()) && !emailPattern.test(contact.value.trim())) {
      setError('contact', 'Enter a valid phone number or email address.');
      isValid = false;
    }

    if (!item.value) {
      setError('item', 'Please choose an item.');
      isValid = false;
    }

    const qty = Number(quantity.value);
    if (!qty || qty < 1 || qty > 50) {
      setError('quantity', 'Enter a quantity between 1 and 50.');
      isValid = false;
    }

    if (!collectionDate.value) {
      setError('collection-date', 'Please select a collection date.');
      isValid = false;
    } else {
      const chosen = new Date(collectionDate.value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (chosen < today) {
        setError('collection-date', 'Collection date cannot be in the past.');
        isValid = false;
      }
    }

    if (isValid) {
      document.getElementById('form-success').style.display = 'block';
      enquiryForm.reset();
    } else {
      document.getElementById('form-success').style.display = 'none';
    }
  });
}

// ---------- Contact form ----------
const contactForm = document.getElementById('contact-form');

if (contactForm) {
  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const name = document.getElementById('c-name');
    const email = document.getElementById('c-email');
    const message = document.getElementById('c-message');

    const errorIds = ['c-name', 'c-email', 'c-message'];
    clearErrors(errorIds);

    let isValid = true;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (name.value.trim().length < 2) {
      setError('c-name', 'Please enter your full name.');
      isValid = false;
    }

    if (!emailPattern.test(email.value.trim())) {
      setError('c-email', 'Please enter a valid email address.');
      isValid = false;
    }

    if (message.value.trim().length < 10) {
      setError('c-message', 'Please enter a message of at least 10 characters.');
      isValid = false;
    }

    if (isValid) {
      document.getElementById('contact-success').style.display = 'block';
      contactForm.reset();
    } else {
      document.getElementById('contact-success').style.display = 'none';
    }
  });
}

// ---------- Mobile navigation: close menu after a link is clicked ----------
const navToggle = document.getElementById('nav-toggle');
document.querySelectorAll('nav a').forEach(link => {
  link.addEventListener('click', () => {
    if (navToggle) navToggle.checked = false;
  });
});
